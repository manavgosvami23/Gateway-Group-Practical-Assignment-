from django import forms
from .models import Trip

class TripForm(forms.ModelForm):
    class Meta:
        model = Trip
        fields = ['start','end','vehicle_type','fuel_type','load_weight']
        widgets = {
            'start': forms.TextInput(attrs={'class':'form-control'}),
            'end': forms.TextInput(attrs={'class':'form-control'}),
            'vehicle_type': forms.Select(attrs={'class':'form-control'}),
            'fuel_type': forms.Select(attrs={'class':'form-control'}),
            'load_weight': forms.NumberInput(attrs={'class':'form-control','step':'0.1'}),
        }
