from django.db import models

class Trip(models.Model):
    start = models.CharField(max_length=255)
    end = models.CharField(max_length=255)
    vehicle_type = models.CharField(max_length=20, choices=[('truck','Truck'),('van','Van'),('car','Car')])
    fuel_type = models.CharField(max_length=20, choices=[('Petrol','Petrol'),('Diesel B7','Diesel B7'),('Electric','Electric')])
    load_weight = models.FloatField()
    distance = models.FloatField(null=True)
    created_at = models.DateTimeField(auto_now_add=True)

class CityEmission(models.Model):
    trip = models.ForeignKey(Trip, on_delete=models.CASCADE)
    city_name = models.CharField(max_length=100)
    lat = models.FloatField()
    lng = models.FloatField()
    dist_km = models.FloatField()
    co2_ttw = models.FloatField()
    co2_wtt = models.FloatField()
    co2_wtw = models.FloatField()
