
from django.urls import path
from .views import index, result

urlpatterns = [
    path('', index, name='index'),
    path('trip/<int:trip_id>/', result, name='trip_result'),
]
