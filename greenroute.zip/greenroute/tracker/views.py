from django.shortcuts import render, redirect, get_object_or_404
from django.forms.models import model_to_dict
from .forms import TripForm
from .models import Trip, CityEmission

EMISSION_FACTORS = {
    'Petrol':    {'ttw': 2.3, 'wtt': 0.2},
    'Diesel B7': {'ttw': 2.6, 'wtt': 0.2},
    'Electric':  {'ttw': 0.5, 'wtt': 0.1},
}

def index(request):
    form = TripForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        trip = form.save()
        distance = 150
        trip.distance = distance
        trip.save()

        CityEmission.objects.filter(trip=trip).delete()
        factors = EMISSION_FACTORS[trip.fuel_type]

        CityEmission.objects.bulk_create([
            CityEmission(
                trip=trip,
                city_name='CityA',
                lat=22.5,
                lng=88.3,
                dist_km=80,
                co2_ttw=80 * factors['ttw'],
                co2_wtt=80 * factors['wtt'],
                co2_wtw=80 * (factors['ttw'] + factors['wtt'])
            ),
            CityEmission(
                trip=trip,
                city_name='CityB',
                lat=23.0,
                lng=87.8,
                dist_km=70,
                co2_ttw=70 * factors['ttw'],
                co2_wtt=70 * factors['wtt'],
                co2_wtw=70 * (factors['ttw'] + factors['wtt'])
            )
        ])

        return redirect('trip_result', trip.id)

    return render(request, 'tracker/index.html', {'form': form})


def result(request, trip_id):
    trip = get_object_or_404(Trip, id=trip_id)
    emissions = CityEmission.objects.filter(trip=trip)

    base = sum(EMISSION_FACTORS['Diesel B7'].values())
    comparison = []

    for fuel, f in EMISSION_FACTORS.items():
        total = round(trip.distance * sum(f.values()), 1)
        pct = round(((total - trip.distance * base) / (trip.distance * base)) * 100, 1) if base else 0

        badge = (
            'secondary' if fuel == 'Diesel B7' else
            'success' if pct <= -50 else
            'warning' if pct < 0 else
            'danger'
        )

        comparison.append({
            'fuel': fuel,
            'total': total,
            'percent_diff': pct,
            'badge': badge
        })

    trip_data = {
        k.replace('_', ' ').capitalize(): v
        for k, v in model_to_dict(trip).items()
    }

    reasoning = (
        "EVs often reduce lifecycle CO₂ emissions by 50–80% compared to diesel—"
        "Transport & Environment notes up to 3× lower in many grids."
    )

    return render(request, 'tracker/result.html', {
        'trip_data': trip_data,
        'emissions': emissions,
        'comparison': comparison,
        'reasoning': reasoning
    })
